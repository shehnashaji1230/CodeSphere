from django.shortcuts import render,redirect
from django.views.generic import View
from .forms import EmployeeForm,PositionForm,RegisterForm,SignInForm
from .models import Employee,Position
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from .decorators import signin_required
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache

# Create your views here.

decs=[signin_required,never_cache]
@method_decorator(decs,name='dispatch')
class EmployeeCreateView(View):
    def get(self,request,id=0,*args,**kwargs):
        if id==0:
            form=EmployeeForm()
        else:
            employee=Employee.objects.get(pk=id)
            form=EmployeeForm(instance=employee)
        return render(request,'empcreate.html',{'form':form})
    def post(self,request,id=0,*args,**kwargs):
        if id==0:
            form=EmployeeForm(request.POST)
        else:
             employee=Employee.objects.get(pk=id)
             form=EmployeeForm(request.POST,instance=employee)
        if form.is_valid():
            
            form.save()
            return redirect('emp-list')
        else:
            return render(request,'empcreate.html',{'form':form})

            
@method_decorator(decs,name='dispatch')
class PositionCreateView(View):
    def get(self,request,*args,**kwargs):
        form=PositionForm()
        return render(request,'positioncreate.html',{'form':form})
    def post(self,request,*args,**kwargs):
        form=PositionForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'posirtion created')
            return redirect('emp-create')
        else:
             messages.error(request,'failed to create')
             return render(request,'positioncreate.html',{'form':form})

@method_decorator(decs,name='dispatch')
class EmployeeListView(View):
    def get(self,request,*args,**kwargs):
       
        qs=Employee.objects.filter(user=request.user)
        selected_position=request.GET.get("position","all")
        
        
        if selected_position=='all':
            qs=qs
            
            
            print(request.user)
            
        else:
              position_obj = Position.objects.get(id=selected_position)  # Or filter by name: get(name=selected_position)
              qs = qs.filter(position=position_obj)
            # qs=qs.filter(position=selected_position)
        return render(request,'emplist.html',{'employees':qs,'selected':selected_position,'position':Position.objects.all()})
        
@method_decorator(decs,name='dispatch')
class EmployeeDeleteView(View):
    def get(self,request,id,*args,**kwargs):
        employee=Employee.objects.get(pk=id)
        employee.delete()
        return redirect('emp-list')

class SignUpView(View):
    template_name='register.html'
    def get(self,request,*args,**kwargs):
        form_instance=RegisterForm()
        return render(request,self.template_name,{'form':form_instance})
    def post(self,request,*args,**kwargs):
        form_instance=RegisterForm(request.POST)
        if form_instance.is_valid():
            data=form_instance.cleaned_data
            User.objects.create_user(**data)
            messages.success(request,'registered successful')
            return redirect('signin')
        else:
            return render(request,self.template_name,{'form':form_instance})

class SignInView(View):
    template_name='login.html'
    def get(self,request,*args,**kwargs):
        form_obj=SignInForm()
        return render(request,self.template_name,{'form':form_obj})
    
    def post(self,request,*args,**kwargs):
        form_obj=SignInForm(request.POST)
        if form_obj.is_valid():
            uname=form_obj.cleaned_data.get('username')
            pwd=form_obj.cleaned_data.get('password')

            # authenticate
            user_obj=authenticate(request,username=uname,password=pwd)
            if user_obj:
                login(request,user_obj)
                
                return redirect('home')
        return render(request,self.template_name,{'form':form_obj})

@method_decorator(decs,name='dispatch')
class SignOutView(View):
    def get(self,request,*args,**kwargs):
        logout(request)
        return redirect('signin')

@method_decorator(decs,name='dispatch')
class HomeView(View):
     def get(self,request,*args,**kwargs):
        
        qs=Employee.objects.all()
        selected_position=request.GET.get("position","all")
        if selected_position=='all':
            qs=qs
        else:
            qs=qs.filter(position=selected_position)
        return render(request,'emplist.html',{'employees':qs,'selected':selected_position,'position':Position.objects.all()})

    
            


